# CHANGELOG.md

## 0.2 (2024-01-22)

Fixes:
    - None

Features:
    - changed all tasks from handlers to components
    - fixed pipeline to have release on command (downloads section)
    - added lint/format & static analysis


## 0.1 (2024-01-15)

Fixes:
    - None

Features:
    - Inital Release without the display
    - regular course wash & dry
    - fixed water level 6
    - no weight detection available
