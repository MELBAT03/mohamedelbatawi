#ifndef NEDIC_DDM_H
#define NEDIC_DDM_H

#include "def.h"
#include "components/uart/uart.h"

typedef enum nedicDDM_error
{
    NEDIC_DDM_NO_ERROR = 0x00,
    NEDIC_DDM_ERROR_GENERAL_FAULT = 0x01,
    NEDIC_DDM_ERROR_IPM_OV_TEMP = 0x02,
    NEDIC_DDM_ERROR_BUS_VOLTAGE = 0x04,
    NEDIC_DDM_ERROR_MOTOR_STALL_TACHO_MISSING = 0x08,
    NEDIC_DDM_ERROR_HW_OV_CURRENT = 0x10,
    NEDIC_DDM_ERROR_BUS_UNDER_VOLTAGE = 0x20,
    NEDIC_DDM_ERROR_LOST_PHASE = 0x40,
    NEDIC_DDM_ERROR_MOTOR_OV_TEMP = 0x80,

    NEDIC_DDM_ERROR_NO_COM = 0x81,
    NEDIC_DDM_ERROR_NACK = 0x82,
    NEDIC_DDM_ERROR_MODE = 0x83,
    NEDIC_DDM_ERROR_FAULT = 0x84,
    NEDIC_DDM_ERROR_CRC = 0x85
} nedicDDM_error_t;

#define NEDIC_DDM_IDLE_TIMEOUT_PERIOD_MS (500U)

#define NEDIC_DDM_HEADER        (0xa5U)
#define NEDIC_DDM_FEEDBACK_ACK  (0xa5U)
#define NEDIC_DDM_FEEDBACK_NACK (0x5AU)

#ifdef CRC_XOR
#define NEDIC_DDM_TX_BUFFER_SIZE 11U
#define NEDIC_DDM_RX_BUFFER_SIZE 18U
#define NEDIC_DDM_RX_DATA_SIZE   7U
#elif defined(CRC_CCITT)
#define NEDIC_DDM_TX_BUFFER_SIZE 12U
#define NEDIC_DDM_RX_BUFFER_SIZE 20U
#define NEDIC_DDM_RX_DATA_SIZE   8U
#endif

typedef enum nedicDDM_state
{
    NEDIC_DDM_SYNC_STATE,
    NEDIC_DDM_BRAKE_STATE,
    NEDIC_DDM_FORCE_BRAKE_STARTUP,
    NEDIC_DDM_FORCE_BRAKE_CANCEL,
    NEDIC_DDM_FORCE_BRAKE_STARTUP_DONE,
    NEDIC_DDM_OPERATION_STATE,
    NEDIC_DDM_FAULT_STATE
} nedicDDM_state_t;

typedef enum nedicDDM_command
{
    NEDIC_DDM_COMMAND_PING = 0x02,
    NEDIC_DDM_COMMAND_REQUEST = 0x05,
    NEDIC_DDM_COMMAND_CW = 0x09,
    NEDIC_DDM_COMMAND_CCW = 0x0b,
    NEDIC_DDM_COMMAND_AGITATION = 0x0c,
    NEDIC_DDM_COMMAND_SPIN = 0x0d,
    NEDIC_DDM_COMMAND_SPIN_PULSATOR = 0x1d,
    NEDIC_DDM_COMMAND_STOP = 0x027,
    NEDIC_DDM_COMMAND_BRAKE = 0x29,
    NEDIC_DDM_COMMAND_VOLTAGE_DETECTION = 0x2b,
    NEDIC_DDM_COMMAND_WEIGHT_DETECTION = 0x2c,
    NEDIC_DDM_COMMAND_FABRIC_DETECTION = 0x2d,
    NEDIC_DDM_COMMAND_CLUTCH = 0x19,
    NEDIC_DDM_COMMAND_DECLUTCH = 0x1A,
    NEDIC_DDM_COMMAND_FORCED_BRAKE = 0x1b
} nedicDDM_command_t;

typedef enum nedicDDM_dataIndex
{
    NEDIC_DDM_DATA_INDEX_HEADER = 0,
    NEDIC_DDM_DATA_INDEX_MODE = 1,
    NEDIC_DDM_DATA_INDEX_ERROR = 2,
    NEDIC_DDM_DATA_INDEX_PLATFORM = 2,
    NEDIC_DDM_DATA_INDEX_MOTOR_SPEED_HIGH_BYTE = 3,
    NEDIC_DDM_DATA_INDEX_MOTOR_SPEED_LOW_BYTE = 4,
    NEDIC_DDM_DATA_INDEX_DC_BUS_VOLTAGE_HIGH_BYTE = 3,
    NEDIC_DDM_DATA_INDEX_DC_BUS_VOLTAGE_LOW_BYTE = 4,
    NEDIC_DDM_DATA_INDEX_SW_VERSION_HIGH_BYTE = 3,
    NEDIC_DDM_DATA_INDEX_SW_VERSION_LOW_BYTE = 4,
    NEDIC_DDM_DATA_INDEX_WEIGHT_HIGH_BYTE = 3,
    NEDIC_DDM_DATA_INDEX_WEIGHT_LOW_BYTE = 4,
    NEDIC_DDM_DATA_INDEX_WEIGHT = 5,
    NEDIC_DDM_DATA_INDEX_FABRIC = 5,
    NEDIC_DDM_DATA_INDEX_CLUTCH_DONE_FLAG = 5,
    NEDIC_DDM_DATA_INDEX_CRC = 6
} nedicDDM_dataIndex_t;

typedef struct nedicDDM_motionPattern
{
    uint32_t cwOnTimeMSec;
    uint32_t cwOffTimeMSec;
    uint32_t ccwOnTimeMSec;
    uint32_t ccwOffTimeMSec;
    uint16_t accTimeMSec;
    uint16_t decTimeMSec;
    uint16_t rpm;
} nedicDDM_motionPattern_t;

typedef struct nedicDDM
{
    uart_t uartx;
    uint32_t txIntervalMS;   // between adjacent commands
    uint32_t receiveTimeoutMS;
    uint8_t platform;
    uint16_t rawTubValue;
} nedicDDM_t;

void nedicDDM_init(nedicDDM_t *motorConfig);

void nedicDDM_update(uint32_t period);

void nedicDDM_command_set(nedicDDM_command_t command, const nedicDDM_motionPattern_t *pattern);

nedicDDM_state_t nedicDDM_state_get(void);
void nedicDDM_state_set(nedicDDM_state_t value);

uint16_t nedicDDM_weightGramFeedback_get(void);
void nedicDDM_weightGramFeedback_set(uint16_t value);
uint16_t nedicDDM_weightRawFeedback_get(void);

uint16_t nedicDDM_swVersion_get(void);

void nedicDDM_clutchDoneFlag_set(uint8_t value);
uint8_t nedicDDM_clutchDoneFlag_get(void);

nedicDDM_error_t nedicDDM_error_get(void);
void nedicDDM_error_set(nedicDDM_error_t value);
uint32_t nedicDDM_speed_get(void);
void nedicDDM_speed_set(uint32_t value);

#endif
