#include "component_config.h"
#include "components/nedic_ddm/nedic_ddm.h"
#include "def.h"
#include "components/uart/uart.h"
#include "os.h"

#include "utils.h"

#define CRC_INITIAL          0xFFFF
#define POLYNOMIAL           0x1021
#define WIDTH                (8 * sizeof(uint16_t))
#define TOP_BIT              (1 << (WIDTH - 1))
#define CRC_TABLE_GENERATION FALSE
#define CRC_FAST             FALSE

static void nedicDDM_highLevel_handle(uint32_t period);
static void nedicDDM_lowLevel_handle(uint32_t period);
static void nedicDDM_data_process(void);

static void nedicDDM_command_generate(nedicDDM_command_t command, nedicDDM_motionPattern_t *controlBlock, uint8_t *buffer);
static uint16_t nedicDDM_crc_get(uint8_t *arr, uint8_t size);
static uint8_t nedicDDM_dataMatch_check(uint8_t *data, uint8_t *ref, uint16_t size);

static uint8_t gau8_nedicDDM_internalTXBuffer[NEDIC_DDM_TX_BUFFER_SIZE] = {0};
static uint8_t gau8_nedicDDM_internalOldTXBuffer[NEDIC_DDM_TX_BUFFER_SIZE] = {0};
static uint8_t gau8_nedicDDM_internalRXBuffer[NEDIC_DDM_RX_BUFFER_SIZE] = {0};
static uint8_t gau8_nedicDDM_feedbackBuffer[NEDIC_DDM_RX_DATA_SIZE] = {0};
static uint8_t gau8_nedicDDM_internalIdleBuffer[NEDIC_DDM_TX_BUFFER_SIZE] = {0};

static nedicDDM_t gx_nedicDDM_internalHandler;
static nedicDDM_motionPattern_t gx_nedicDDM_internalMotorControlBlock;

static uint8_t forcedBrake_flag = 0;

static nedicDDM_state_t gx_nedicDDM_state;

static nedicDDM_command_t gx_nedicDDM_command = NEDIC_DDM_COMMAND_REQUEST;

static nedicDDM_error_t gx_nedicDDM_internalErrorHandler;
static uint16_t gu16_nedicDDM_swVersion = 0;

static uint16_t rawWeightFeedback = 0;
static uint16_t gramWeightFeedback = 0;
static uint8_t clutchDone_flag = 0;
static uint32_t motorSpeed = 0;

void nedicDDM_init(nedicDDM_t *motorConfig)
{
    gx_nedicDDM_state = NEDIC_DDM_SYNC_STATE;

    gx_nedicDDM_internalHandler.uartx = motorConfig->uartx;
    gx_nedicDDM_internalHandler.txIntervalMS = motorConfig->txIntervalMS;
    gx_nedicDDM_internalHandler.receiveTimeoutMS = motorConfig->receiveTimeoutMS;
    gx_nedicDDM_internalHandler.platform = motorConfig->platform;
    gx_nedicDDM_internalHandler.rawTubValue = motorConfig->rawTubValue;

    nedicDDM_command_generate(NEDIC_DDM_COMMAND_REQUEST, NULL, gau8_nedicDDM_internalIdleBuffer);

    gx_nedicDDM_internalErrorHandler = NEDIC_DDM_NO_ERROR;
}

void nedicDDM_update(uint32_t period)
{
    nedicDDM_highLevel_handle(period);
    nedicDDM_lowLevel_handle(period);
}

void nedicDDM_command_set(nedicDDM_command_t command, const nedicDDM_motionPattern_t *pattern)
{
    gx_nedicDDM_command = command;

    if (pattern != NULL)
    {
        gx_nedicDDM_internalMotorControlBlock.accTimeMSec = pattern->accTimeMSec;
        gx_nedicDDM_internalMotorControlBlock.ccwOffTimeMSec = pattern->ccwOffTimeMSec;
        gx_nedicDDM_internalMotorControlBlock.ccwOnTimeMSec = pattern->ccwOnTimeMSec;
        gx_nedicDDM_internalMotorControlBlock.cwOffTimeMSec = pattern->cwOffTimeMSec;
        gx_nedicDDM_internalMotorControlBlock.cwOnTimeMSec = pattern->cwOnTimeMSec;
        gx_nedicDDM_internalMotorControlBlock.decTimeMSec = pattern->decTimeMSec;

#ifdef MOTOR_SPEED_LIMIT_ENABLE
        if (gx_nedicDDM_internalMotorControlBlock.rpm > NEDIC_DDM_MOTOR_SPEED_LIMIT)
        {
            gx_nedicDDM_internalMotorControlBlock.rpm = NEDIC_DDM_MOTOR_SPEED_LIMIT;
        }
        else
        {
            gx_nedicDDM_internalMotorControlBlock.rpm = pattern->rpm;
        }
#else
        gx_nedicDDM_internalMotorControlBlock.rpm = pattern->rpm;
#endif
        if (NEDIC_DDM_COMMAND_AGITATION == command)
        {
            gx_nedicDDM_internalMotorControlBlock.rpm *= 5.33;
        }
    }
}

nedicDDM_state_t nedicDDM_state_get(void)
{
    return gx_nedicDDM_state;
}
void nedicDDM_state_set(nedicDDM_state_t value)
{
    gx_nedicDDM_state = value;
}

uint16_t nedicDDM_weightGramFeedback_get(void)
{
    return gramWeightFeedback;
}
void nedicDDM_weightGramFeedback_set(uint16_t value)
{
    gramWeightFeedback = value;
}
uint16_t nedicDDM_weightRawFeedback_get(void)
{
    return rawWeightFeedback;
}

uint16_t nedicDDM_swVersion_get(void)
{
    return gu16_nedicDDM_swVersion;
}

void nedicDDM_clutchDoneFlag_set(uint8_t value)
{
    clutchDone_flag = value;
}
uint8_t nedicDDM_clutchDoneFlag_get(void)
{
    return clutchDone_flag;
}

nedicDDM_error_t nedicDDM_error_get(void)
{
    return gx_nedicDDM_internalErrorHandler;
}
void nedicDDM_error_set(nedicDDM_error_t value)
{
    gx_nedicDDM_internalErrorHandler = value;
}

uint32_t nedicDDM_speed_get(void)
{
    return motorSpeed;
}
void nedicDDM_speed_set(uint32_t value)
{
    motorSpeed = value;
}

static void nedicDDM_highLevel_handle(uint32_t period)
{
    static uint32_t timeoutMSec = 0;
    static uint32_t faultTimeoutMSec = 0;

    if (NEDIC_DDM_NO_ERROR != gx_nedicDDM_internalErrorHandler)
    {
        faultTimeoutMSec += period;
        if (faultTimeoutMSec >= 10000U)
        {
            faultTimeoutMSec = 0;
            gx_nedicDDM_state = NEDIC_DDM_FAULT_STATE;
        }
    }
    else
    {
        faultTimeoutMSec = 0;
        if (gau8_nedicDDM_feedbackBuffer[NEDIC_DDM_DATA_INDEX_MODE] == NEDIC_DDM_COMMAND_REQUEST)
        {
            motorSpeed = (gau8_nedicDDM_feedbackBuffer[NEDIC_DDM_DATA_INDEX_MOTOR_SPEED_HIGH_BYTE] << 8) | gau8_nedicDDM_feedbackBuffer[NEDIC_DDM_DATA_INDEX_MOTOR_SPEED_LOW_BYTE];
            gx_nedicDDM_internalErrorHandler = (nedicDDM_error_t)gau8_nedicDDM_feedbackBuffer[NEDIC_DDM_DATA_INDEX_ERROR];
        }
    }

    switch (gx_nedicDDM_state)
    {
        case NEDIC_DDM_SYNC_STATE:
        {
            nedicDDM_command_generate(NEDIC_DDM_COMMAND_PING, NULL, gau8_nedicDDM_internalTXBuffer);

            if (gau8_nedicDDM_feedbackBuffer[NEDIC_DDM_DATA_INDEX_MODE] == NEDIC_DDM_COMMAND_PING)
            {
                gx_nedicDDM_state = NEDIC_DDM_BRAKE_STATE;
                gu16_nedicDDM_swVersion = (uint16_t)((uint16_t)gau8_nedicDDM_feedbackBuffer[NEDIC_DDM_DATA_INDEX_SW_VERSION_HIGH_BYTE] << 8) | (gau8_nedicDDM_feedbackBuffer[NEDIC_DDM_DATA_INDEX_SW_VERSION_LOW_BYTE]);
            }
        }
        break;

        case NEDIC_DDM_BRAKE_STATE:
        {
            nedicDDM_command_generate(NEDIC_DDM_COMMAND_BRAKE, NULL, gau8_nedicDDM_internalTXBuffer);

            if (gau8_nedicDDM_feedbackBuffer[NEDIC_DDM_DATA_INDEX_MODE] == NEDIC_DDM_COMMAND_BRAKE)
            {
                if ((gau8_nedicDDM_feedbackBuffer[NEDIC_DDM_DATA_INDEX_ERROR] == 0x00) && (gau8_nedicDDM_feedbackBuffer[NEDIC_DDM_DATA_INDEX_MOTOR_SPEED_HIGH_BYTE] == 0 && gau8_nedicDDM_feedbackBuffer[NEDIC_DDM_DATA_INDEX_MOTOR_SPEED_LOW_BYTE] == 0))
                {
                    gx_nedicDDM_state = NEDIC_DDM_FORCE_BRAKE_STARTUP;
                }
                else
                {
                    gx_nedicDDM_internalErrorHandler = NEDIC_DDM_ERROR_GENERAL_FAULT;
                }
            }
        }
        break;

        case NEDIC_DDM_FORCE_BRAKE_STARTUP:
        {
            forcedBrake_flag = 1;
            nedicDDM_command_generate(NEDIC_DDM_COMMAND_FORCED_BRAKE, NULL, gau8_nedicDDM_internalTXBuffer);

            if (gau8_nedicDDM_feedbackBuffer[NEDIC_DDM_DATA_INDEX_MODE] == NEDIC_DDM_COMMAND_FORCED_BRAKE)
            {
                if ((gau8_nedicDDM_feedbackBuffer[NEDIC_DDM_DATA_INDEX_ERROR] == 0x00) && (gau8_nedicDDM_feedbackBuffer[NEDIC_DDM_DATA_INDEX_MOTOR_SPEED_HIGH_BYTE] == 0 && gau8_nedicDDM_feedbackBuffer[NEDIC_DDM_DATA_INDEX_MOTOR_SPEED_LOW_BYTE] == 0))
                {
                    timeoutMSec += period;
                    if (timeoutMSec >= 1000)
                    {
                        timeoutMSec = 0;
                        gx_nedicDDM_state = NEDIC_DDM_FORCE_BRAKE_CANCEL;
                    }
                }
                else
                {
                    gx_nedicDDM_internalErrorHandler = NEDIC_DDM_ERROR_GENERAL_FAULT;
                }
            }
        }
        break;

        case NEDIC_DDM_FORCE_BRAKE_CANCEL:
        {
            forcedBrake_flag = 0;
            nedicDDM_command_generate(NEDIC_DDM_COMMAND_FORCED_BRAKE, NULL, gau8_nedicDDM_internalTXBuffer);

            timeoutMSec += period;
            if (timeoutMSec >= 1000)
            {
                timeoutMSec = 0;
                gx_nedicDDM_state = NEDIC_DDM_FORCE_BRAKE_STARTUP_DONE;
            }
        }
        break;

        case NEDIC_DDM_FORCE_BRAKE_STARTUP_DONE:
        {
            nedicDDM_command_generate(NEDIC_DDM_COMMAND_BRAKE, NULL, gau8_nedicDDM_internalTXBuffer);

            if ((gau8_nedicDDM_feedbackBuffer[NEDIC_DDM_DATA_INDEX_MODE] == NEDIC_DDM_COMMAND_BRAKE) || (gau8_nedicDDM_feedbackBuffer[NEDIC_DDM_DATA_INDEX_MODE] == NEDIC_DDM_COMMAND_REQUEST))
            {
                timeoutMSec += period;
                if (timeoutMSec >= 1000)
                {
                    timeoutMSec = 0;
                    gx_nedicDDM_state = NEDIC_DDM_OPERATION_STATE;
                }
            }
        }
        break;

        case NEDIC_DDM_OPERATION_STATE:
        {
            nedicDDM_command_generate(gx_nedicDDM_command, &gx_nedicDDM_internalMotorControlBlock, gau8_nedicDDM_internalTXBuffer);

            if (gau8_nedicDDM_feedbackBuffer[NEDIC_DDM_DATA_INDEX_MODE] == NEDIC_DDM_COMMAND_CW || gau8_nedicDDM_feedbackBuffer[NEDIC_DDM_DATA_INDEX_MODE] == NEDIC_DDM_COMMAND_CCW || gau8_nedicDDM_feedbackBuffer[NEDIC_DDM_DATA_INDEX_MODE] == NEDIC_DDM_COMMAND_AGITATION || gau8_nedicDDM_feedbackBuffer[NEDIC_DDM_DATA_INDEX_MODE] == NEDIC_DDM_COMMAND_SPIN || gau8_nedicDDM_feedbackBuffer[NEDIC_DDM_DATA_INDEX_MODE] == NEDIC_DDM_COMMAND_SPIN_PULSATOR || gau8_nedicDDM_feedbackBuffer[NEDIC_DDM_DATA_INDEX_MODE] == NEDIC_DDM_COMMAND_STOP || gau8_nedicDDM_feedbackBuffer[NEDIC_DDM_DATA_INDEX_MODE] == NEDIC_DDM_COMMAND_BRAKE || gau8_nedicDDM_feedbackBuffer[NEDIC_DDM_DATA_INDEX_MODE] == NEDIC_DDM_COMMAND_FORCED_BRAKE)
            {
                motorSpeed = (gau8_nedicDDM_feedbackBuffer[NEDIC_DDM_DATA_INDEX_MOTOR_SPEED_HIGH_BYTE] << 8) | gau8_nedicDDM_feedbackBuffer[NEDIC_DDM_DATA_INDEX_MOTOR_SPEED_LOW_BYTE];
                gx_nedicDDM_internalErrorHandler = (nedicDDM_error_t)gau8_nedicDDM_feedbackBuffer[NEDIC_DDM_DATA_INDEX_ERROR];
                clutchDone_flag = 0;
            }
            else if (gau8_nedicDDM_feedbackBuffer[NEDIC_DDM_DATA_INDEX_MODE] == NEDIC_DDM_COMMAND_WEIGHT_DETECTION)
            {
                gx_nedicDDM_internalErrorHandler = (nedicDDM_error_t)gau8_nedicDDM_feedbackBuffer[NEDIC_DDM_DATA_INDEX_ERROR];
                if (gx_nedicDDM_internalErrorHandler == NEDIC_DDM_NO_ERROR)
                {
                    rawWeightFeedback = ((uint32_t)gau8_nedicDDM_feedbackBuffer[NEDIC_DDM_DATA_INDEX_WEIGHT_HIGH_BYTE] << 8) | gau8_nedicDDM_feedbackBuffer[NEDIC_DDM_DATA_INDEX_WEIGHT_LOW_BYTE];
                    gramWeightFeedback = gau8_nedicDDM_feedbackBuffer[NEDIC_DDM_DATA_INDEX_WEIGHT] * 100;
                }
                else
                {
                    gx_nedicDDM_internalErrorHandler = NEDIC_DDM_NO_ERROR;
                    rawWeightFeedback = UINT16_MAX;
                    gramWeightFeedback = UINT16_MAX;
                }
                motorSpeed = 0;
            }
            else if (gau8_nedicDDM_feedbackBuffer[NEDIC_DDM_DATA_INDEX_MODE] == NEDIC_DDM_COMMAND_CLUTCH || gau8_nedicDDM_feedbackBuffer[NEDIC_DDM_DATA_INDEX_MODE] == NEDIC_DDM_COMMAND_DECLUTCH)
            {
                clutchDone_flag = gau8_nedicDDM_feedbackBuffer[NEDIC_DDM_DATA_INDEX_CLUTCH_DONE_FLAG];
                motorSpeed = 0;
                gx_nedicDDM_internalErrorHandler = (nedicDDM_error_t)gau8_nedicDDM_feedbackBuffer[NEDIC_DDM_DATA_INDEX_ERROR];
            }
            else
            {
                // do nothing
            }
        }
        break;

        case NEDIC_DDM_FAULT_STATE:
        {
            motorSpeed = UINT32_MAX;   // to indicate fault
            clutchDone_flag = 0;
        }
        break;

        default:
        {
            // do nothing
        }
        break;
    }
}

static void nedicDDM_lowLevel_handle(uint32_t period)
{
    static uint32_t internalTXIntervalCounter = 0, internalRXTimeout = 0;
    int16_t ret = 0;
    static uint8_t rxCounter = 0;

    internalTXIntervalCounter += period;
    if ((internalTXIntervalCounter >= gx_nedicDDM_internalHandler.txIntervalMS))
    {
        internalTXIntervalCounter = 0;
        rxCounter = 0;

        if (gau8_nedicDDM_internalTXBuffer[NEDIC_DDM_DATA_INDEX_MODE] != NEDIC_DDM_COMMAND_CLUTCH && gau8_nedicDDM_internalTXBuffer[NEDIC_DDM_DATA_INDEX_MODE] != NEDIC_DDM_COMMAND_DECLUTCH && gau8_nedicDDM_internalTXBuffer[NEDIC_DDM_DATA_INDEX_MODE] != NEDIC_DDM_COMMAND_WEIGHT_DETECTION && gau8_nedicDDM_internalTXBuffer[NEDIC_DDM_DATA_INDEX_MODE] != NEDIC_DDM_COMMAND_FORCED_BRAKE && nedicDDM_dataMatch_check(gau8_nedicDDM_internalOldTXBuffer, gau8_nedicDDM_internalTXBuffer, NEDIC_DDM_TX_BUFFER_SIZE))
        {
            for (uint8_t i = 0; i < NEDIC_DDM_TX_BUFFER_SIZE; i++)
            {
                uart_byte_put(gx_nedicDDM_internalHandler.uartx, gau8_nedicDDM_internalIdleBuffer[i]);
            }
        }
        else
        {
            for (uint8_t i = 0; i < NEDIC_DDM_TX_BUFFER_SIZE; i++)
            {
                uart_byte_put(gx_nedicDDM_internalHandler.uartx, gau8_nedicDDM_internalTXBuffer[i]);
                gau8_nedicDDM_internalOldTXBuffer[i] = gau8_nedicDDM_internalTXBuffer[i];
            }
        }
    }

    if (uart_recv_check(gx_nedicDDM_internalHandler.uartx) == TRUE)
    {
        internalRXTimeout = 0;
        if ((ret = uart_bytesAvailable_get(gx_nedicDDM_internalHandler.uartx, &gau8_nedicDDM_internalRXBuffer[rxCounter])) != -1)
        {
            rxCounter += ret;
            // printf("count %d\n\r", rxCounter);
            // for (uint8_t i = 0; i < rxCounter; i++)
            // {
            //     printf("%02x ", gau8_nedicDDM_internalRXBuffer[i]);
            // }
            // printf("\n\r");
        }

        if (rxCounter >= NEDIC_DDM_RX_BUFFER_SIZE)
        {
            internalRXTimeout = 0;
            rxCounter = 0;

            LOG_C('n', 'v', "RX inside : %2x %2x %2x %2x %2x %2x %2x %2x %2x %2x %2x %2x          %2x %2x %2x %2x %2x %2x %2x %2x  State:%d   Err:%d", gau8_nedicDDM_internalRXBuffer[0], gau8_nedicDDM_internalRXBuffer[1], gau8_nedicDDM_internalRXBuffer[2], gau8_nedicDDM_internalRXBuffer[3], gau8_nedicDDM_internalRXBuffer[4], gau8_nedicDDM_internalRXBuffer[5], gau8_nedicDDM_internalRXBuffer[6], gau8_nedicDDM_internalRXBuffer[7], gau8_nedicDDM_internalRXBuffer[8], gau8_nedicDDM_internalRXBuffer[9], gau8_nedicDDM_internalRXBuffer[10], gau8_nedicDDM_internalRXBuffer[11], gau8_nedicDDM_internalRXBuffer[12], gau8_nedicDDM_internalRXBuffer[13], gau8_nedicDDM_internalRXBuffer[14], gau8_nedicDDM_internalRXBuffer[15], gau8_nedicDDM_internalRXBuffer[16], gau8_nedicDDM_internalRXBuffer[17], gau8_nedicDDM_internalRXBuffer[18], gau8_nedicDDM_internalRXBuffer[19], gx_nedicDDM_state, gx_nedicDDM_internalErrorHandler);

            nedicDDM_data_process();
        }
    }
    else
    {
        internalRXTimeout += period;
        if (internalRXTimeout >= gx_nedicDDM_internalHandler.receiveTimeoutMS)
        {
            internalRXTimeout = 0;
            gx_nedicDDM_internalErrorHandler = NEDIC_DDM_ERROR_NO_COM;
            rxCounter = 0;
            for (uint8_t i = 0; i < NEDIC_DDM_RX_BUFFER_SIZE; i++)
            {
                gau8_nedicDDM_internalRXBuffer[i] = 0;
            }
        }
    }
}

static void nedicDDM_data_process(void)
{
    if (gau8_nedicDDM_internalRXBuffer[NEDIC_DDM_DATA_INDEX_HEADER + NEDIC_DDM_TX_BUFFER_SIZE] == NEDIC_DDM_FEEDBACK_ACK)
    {
        if (gau8_nedicDDM_internalRXBuffer[NEDIC_DDM_DATA_INDEX_MODE + NEDIC_DDM_TX_BUFFER_SIZE] == gau8_nedicDDM_internalTXBuffer[NEDIC_DDM_DATA_INDEX_MODE] || gau8_nedicDDM_internalRXBuffer[NEDIC_DDM_DATA_INDEX_MODE + NEDIC_DDM_TX_BUFFER_SIZE] == NEDIC_DDM_COMMAND_REQUEST)
        {
#ifdef CRC_XOR
            if (nedicDDM_crc_get(&gau8_nedicDDM_internalRXBuffer[NEDIC_DDM_TX_BUFFER_SIZE], NEDIC_DDM_RX_DATA_SIZE - 1) != gau8_nedicDDM_internalRXBuffer[NEDIC_DDM_DATA_INDEX_CRC + NEDIC_DDM_TX_BUFFER_SIZE])
#elif defined(CRC_CCITT)
            if (nedicDDM_crc_get(&gau8_nedicDDM_internalRXBuffer[NEDIC_DDM_TX_BUFFER_SIZE], NEDIC_DDM_RX_DATA_SIZE - 2) != (((uint16_t)((uint16_t)gau8_nedicDDM_internalRXBuffer[NEDIC_DDM_DATA_INDEX_CRC + NEDIC_DDM_TX_BUFFER_SIZE]) << 8) | ((uint16_t)gau8_nedicDDM_internalRXBuffer[NEDIC_DDM_DATA_INDEX_CRC + NEDIC_DDM_TX_BUFFER_SIZE + 1])))
#endif
            {
                gx_nedicDDM_internalErrorHandler = NEDIC_DDM_ERROR_CRC;
            }
            else
            {
                for (uint8_t j = 0; j < NEDIC_DDM_RX_DATA_SIZE; j++)
                {
                    gau8_nedicDDM_feedbackBuffer[j] = gau8_nedicDDM_internalRXBuffer[j + NEDIC_DDM_TX_BUFFER_SIZE];
                }
            }
        }
        else
        {
            gx_nedicDDM_internalErrorHandler = NEDIC_DDM_ERROR_MODE;
        }
    }
    else if (gau8_nedicDDM_internalRXBuffer[NEDIC_DDM_DATA_INDEX_HEADER + NEDIC_DDM_TX_BUFFER_SIZE] == NEDIC_DDM_FEEDBACK_NACK)
    {
        gx_nedicDDM_internalErrorHandler = NEDIC_DDM_ERROR_NACK;
    }
    else
    {
        gx_nedicDDM_internalErrorHandler = NEDIC_DDM_ERROR_NO_COM;
    }
}

static void nedicDDM_command_generate(nedicDDM_command_t command, nedicDDM_motionPattern_t *controlBlock, uint8_t *buffer)
{
    uint8_t j = 0;
    uint8_t usedBytes = 0;

    buffer[j++] = NEDIC_DDM_HEADER;

    switch (command)
    {
        case NEDIC_DDM_COMMAND_PING:
            if (gx_nedicDDM_internalHandler.rawTubValue >= 0x0fff || gx_nedicDDM_internalHandler.rawTubValue < 1800)
            {
                gx_nedicDDM_internalHandler.rawTubValue = 0;
            }
            buffer[j++] = (uint8_t)command;
            buffer[j++] = gx_nedicDDM_internalHandler.platform;
            buffer[j++] = (uint8_t)(gx_nedicDDM_internalHandler.rawTubValue >> 8);
            buffer[j++] = (uint8_t)(gx_nedicDDM_internalHandler.rawTubValue & 0x00ff);
            usedBytes = j;
            break;

            // case NEDIC_DDM_COMMAND_SPIN:
            // case NEDIC_DDM_COMMAND_SPIN_PULSATOR:
        case NEDIC_DDM_COMMAND_CW:
        case NEDIC_DDM_COMMAND_CCW:
        {
            if (NULL != controlBlock)
            {
                if (controlBlock->rpm > NEDIC_DDM_MOTOR_MAX_RPM)
                {
                    controlBlock->rpm = NEDIC_DDM_MOTOR_MAX_RPM;
                }

                buffer[j++] = (uint8_t)command;
                buffer[j++] = (uint8_t)(controlBlock->rpm >> 8) & 0x00ff;
                buffer[j++] = (uint8_t)(controlBlock->rpm & 0x00ff);
                buffer[j++] = (uint8_t)((controlBlock->accTimeMSec / 100) >> 8) & 0x00ff;
                buffer[j++] = (uint8_t)(controlBlock->accTimeMSec / 100) & 0x00ff;
                usedBytes = j;
            }
        }
        break;

        case NEDIC_DDM_COMMAND_AGITATION:
            if (NULL != controlBlock)
            {
                if (controlBlock->rpm > NEDIC_DDM_MOTOR_MAX_RPM)
                {
                    controlBlock->rpm = NEDIC_DDM_MOTOR_MAX_RPM;
                }

                buffer[j++] = (uint8_t)command;
                buffer[j++] = (uint8_t)(controlBlock->rpm >> 8) & 0x00ff;
                buffer[j++] = (uint8_t)(controlBlock->rpm & 0x00ff);
                buffer[j++] = (uint8_t)(controlBlock->accTimeMSec / 100);
                buffer[j++] = (uint8_t)(controlBlock->decTimeMSec / 100);
                buffer[j++] = (uint8_t)(controlBlock->cwOnTimeMSec / 100);
                buffer[j++] = (uint8_t)(controlBlock->cwOffTimeMSec / 100);
                buffer[j++] = (uint8_t)(controlBlock->ccwOnTimeMSec / 100);
                buffer[j++] = (uint8_t)(controlBlock->ccwOffTimeMSec / 100);
                usedBytes = j;
            }
            break;

        case NEDIC_DDM_COMMAND_REQUEST:
        case NEDIC_DDM_COMMAND_STOP:
        case NEDIC_DDM_COMMAND_BRAKE:
        case NEDIC_DDM_COMMAND_VOLTAGE_DETECTION:
        case NEDIC_DDM_COMMAND_WEIGHT_DETECTION:
        case NEDIC_DDM_COMMAND_FABRIC_DETECTION:
            buffer[j++] = (uint8_t)command;
            usedBytes = j;
            break;

        case NEDIC_DDM_COMMAND_CLUTCH:
            buffer[j++] = (uint8_t)command;
            buffer[j++] = 1;
            usedBytes = j;
            break;

        case NEDIC_DDM_COMMAND_DECLUTCH:
            buffer[j++] = 0x19;
            buffer[j++] = 0;
            usedBytes = j;
            break;

        case NEDIC_DDM_COMMAND_FORCED_BRAKE:
            buffer[j++] = (uint8_t)command;
            buffer[j++] = (uint8_t)(forcedBrake_flag);   // set to 1 to enable, 0 to disable
            usedBytes = j;
            break;

        default:
            // do nothing
            break;
    }

    // fill the rest of the command with zeros (must)
    for (uint8_t i = usedBytes; i < NEDIC_DDM_TX_BUFFER_SIZE - 1; i++)
    {
        buffer[i] = 0x00;
    }
#ifdef CRC_XOR
    buffer[NEDIC_DDM_TX_BUFFER_SIZE - 1] = nedicDDM_crc_get(buffer, NEDIC_DDM_TX_BUFFER_SIZE - 1);
#elif defined(CRC_CCITT)
    uint16_t crc = nedicDDM_crc_get(buffer, NEDIC_DDM_TX_BUFFER_SIZE - 2);
    buffer[NEDIC_DDM_TX_BUFFER_SIZE - 2] = (uint8_t)(((uint16_t)crc & 0xff00) >> 8U);
    buffer[NEDIC_DDM_TX_BUFFER_SIZE - 1] = (uint8_t)((uint16_t)crc & 0x00ff);
#endif
}

static uint16_t nedicDDM_crc_get(uint8_t *arr, uint8_t size)
{
#ifdef CRC_XOR
    uint8_t ret, i = 0;

    ret = 0;

    for (i = 0; i < size; i++)
    {
        ret ^= arr[i];
    }

    return ret;

#elif defined(CRC_CCITT)
    uint16_t bytes;
    uint16_t remainder;
    uint8_t bit;

    remainder = CRC_INITIAL;

    for (bytes = 0; bytes < size; bytes++)
    {
        /* Bring next byte into the remainder */
        remainder ^= (arr[bytes] << (WIDTH - 8));

        /* Perform mod-2 division bit by bit */
        for (bit = 8; bit > 0; bit--)
        {
            /* Try to divide the current data bit */
            if (remainder & TOP_BIT)
            {
                remainder = (remainder << 1) ^ POLYNOMIAL;
            }
            else
            {
                remainder = (remainder << 1);
            }
        }
    }

    return remainder; /* The final remainder is the CRC */
#endif
}

static uint8_t nedicDDM_dataMatch_check(uint8_t *data, uint8_t *ref, uint16_t size)
{
    uint16_t i = 0;

    while (size > i)
    {
        if (data[i] != ref[i])
        {
            return 0;
        }
        i++;
    }
    return 1;
}
