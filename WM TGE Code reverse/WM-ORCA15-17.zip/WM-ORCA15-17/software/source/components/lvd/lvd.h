#ifndef COMPONENT_LOW_V_DETECTION
#define COMPONENT_LOW_V_DETECTION 1

void lvd_init(void);

#endif
