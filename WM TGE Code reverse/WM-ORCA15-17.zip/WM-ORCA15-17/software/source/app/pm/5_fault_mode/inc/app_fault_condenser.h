#ifndef APP_FAULT_CONDENSER_H
#define APP_FAULT_CONDENSER_H

#include "def.h"

void app_fault_condenser_process(uint32_t period);

#endif
