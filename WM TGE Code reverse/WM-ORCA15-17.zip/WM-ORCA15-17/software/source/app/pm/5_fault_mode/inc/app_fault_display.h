#ifndef APP_FAULT_DISPLAY_H
#define APP_FAULT_DISPLAY_H

#include "def.h"

void app_fault_display_process(uint32_t period);

#endif
