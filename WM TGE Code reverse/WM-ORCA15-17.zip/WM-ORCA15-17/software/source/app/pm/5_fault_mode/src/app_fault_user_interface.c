#include "def.h"

#include "app_fault_user_interface.h"

#include "app_user_interface.h"

void app_fault_userInterface_process(uint32_t period)
{
    // do nothing
}
