#ifndef APP_FAULT_COOLING_FAN_H
#define APP_FAULT_COOLING_FAN_H

#include "def.h"

void app_fault_coolingFan_process(uint32_t period);

#endif
