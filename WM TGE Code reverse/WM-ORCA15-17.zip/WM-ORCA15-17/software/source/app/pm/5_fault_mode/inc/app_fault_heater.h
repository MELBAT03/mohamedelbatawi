#ifndef APP_FAULT_HEATER_H
#define APP_FAULT_HEATER_H

#include "def.h"

void app_fault_heater_process(uint32_t period);

#endif
