#ifndef APP_FAULT_BLOWER_H
#define APP_FAULT_BLOWER_H

#include "def.h"

void app_fault_blower_process(uint32_t period);

#endif
