#ifndef APP_FAULT_USER_INTERFACE_H
#define APP_FAULT_USER_INTERFACE_H

#include "def.h"

void app_fault_userInterface_process(uint32_t period);

#endif
