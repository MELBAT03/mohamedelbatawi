#ifndef APP_FAULT_MOTOR_H
#define APP_FAULT_MOTOR_H

#include "def.h"

void app_fault_motor_process(uint32_t period);

#endif
