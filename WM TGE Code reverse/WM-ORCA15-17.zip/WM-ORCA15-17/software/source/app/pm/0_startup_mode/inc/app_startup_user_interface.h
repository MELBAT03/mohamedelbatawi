#ifndef APP_STARTUP_USER_INTERFACE_H
#define APP_STARTUP_USER_INTERFACE_H

#include "def.h"

void app_startup_userInterface_process(uint32_t period);

#endif
