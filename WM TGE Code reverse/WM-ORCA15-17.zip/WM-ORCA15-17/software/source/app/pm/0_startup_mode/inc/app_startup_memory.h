#ifndef APP_STARTUP_MEMORY_H
#define APP_STARTUP_MEMORY_H

#include "def.h"

void app_startup_memory_process(uint32_t period);

#endif
