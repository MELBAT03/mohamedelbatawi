#ifndef APP_STARTUP_DRAIN_H
#define APP_STARTUP_DRAIN_H

#include "def.h"

void app_startup_drain_process(uint32_t period);

#endif
