#ifndef APP_STARTUP_COOLING_FAN_H
#define APP_STARTUP_COOLING_FAN_H

#include "def.h"

void app_startup_coolingFan_process(uint32_t period);

#endif
