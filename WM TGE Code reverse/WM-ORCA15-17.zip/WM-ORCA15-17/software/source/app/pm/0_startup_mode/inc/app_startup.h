#ifndef APP_STARTUP_H
#define APP_STARTUP_H

#include "def.h"

#include "app_processor.h"

app_processor_state_t app_startup_process(uint32_t period);

#endif
