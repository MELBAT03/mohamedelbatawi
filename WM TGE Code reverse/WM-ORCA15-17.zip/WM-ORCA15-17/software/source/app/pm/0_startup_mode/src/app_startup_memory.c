#include "def.h"

#include "app_memory.h"

#include "app_startup_memory.h"

void app_startup_memory_process(uint32_t period)
{
    app_memory_init();
}
