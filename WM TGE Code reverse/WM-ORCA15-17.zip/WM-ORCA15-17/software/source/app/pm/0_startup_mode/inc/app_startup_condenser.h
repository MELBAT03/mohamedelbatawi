#ifndef APP_STARTUP_CONDENSER_H
#define APP_STARTUP_CONDENSER_H

#include "def.h"

void app_startup_condenser_process(uint32_t period);

#endif
