#ifndef APP_STARTUP_FILL_H
#define APP_STARTUP_FILL_H

#include "def.h"

void app_startup_fill_process(uint32_t period);

#endif
