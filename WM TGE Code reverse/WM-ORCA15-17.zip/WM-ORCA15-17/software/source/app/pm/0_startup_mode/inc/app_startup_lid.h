#ifndef APP_STARTUP_LID_H
#define APP_STARTUP_LID_H

#include "def.h"

void app_startup_lid_process(uint32_t period);

#endif
