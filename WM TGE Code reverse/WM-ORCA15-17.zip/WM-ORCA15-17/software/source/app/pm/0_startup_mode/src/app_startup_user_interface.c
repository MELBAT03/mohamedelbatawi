#include "def.h"

#include "app_startup_user_interface.h"

#include "app_memory.h"
#include "app_nm_user_interface.h"

void app_startup_userInterface_process(uint32_t period)
{
    // do nothing
}
