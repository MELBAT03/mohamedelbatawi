#ifndef APP_STARTUP_BLOWER_H
#define APP_STARTUP_BLOWER_H

#include "def.h"

void app_startup_blower_process(uint32_t period);

#endif
