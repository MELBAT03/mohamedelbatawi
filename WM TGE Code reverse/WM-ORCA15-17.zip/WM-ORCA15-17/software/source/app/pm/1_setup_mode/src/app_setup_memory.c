#include "def.h"

#include "app_memory.h"

#include "app_setup_memory.h"

void app_setup_memory_process(uint32_t period)
{
    // do nothing
}
