#ifndef APP_SETUP_MEMORY_H
#define APP_SETUP_MEMORY_H

#include "def.h"

void app_setup_memory_process(uint32_t period);

#endif
