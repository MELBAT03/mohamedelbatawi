#ifndef APP_SETUP_USER_INTERFACE_H
#define APP_SETUP_USER_INTERFACE_H

#include "def.h"

void app_setup_userInterface_process(uint32_t period);

#endif
