#ifndef APP_SETUP_CONDENSER_H
#define APP_SETUP_CONDENSER_H

#include "def.h"

void app_setup_condenser_process(uint32_t period);

#endif
