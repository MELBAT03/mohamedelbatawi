#ifndef APP_SETUP_H
#define APP_SETUP_H

#include "def.h"

#include "app_processor.h"

app_processor_state_t app_setup_process(uint32_t period);

void setup_nm_data_handle(void);

#endif
