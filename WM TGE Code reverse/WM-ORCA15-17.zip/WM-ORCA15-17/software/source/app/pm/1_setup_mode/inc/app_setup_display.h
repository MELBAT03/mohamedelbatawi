#ifndef APP_SETUP_DISPLAY_H
#define APP_SETUP_DISPLAY_H

#include "def.h"

void app_setup_display_process(uint32_t period);

#endif
