#ifndef APP_SETUP_LID_H
#define APP_SETUP_LID_H

#include "def.h"

void app_setup_lid_process(uint32_t period);

#endif
