#ifndef APP_SETUP_MOTOR_H
#define APP_SETUP_MOTOR_H

#include "def.h"

void app_setup_motor_process(uint32_t period);

#endif
