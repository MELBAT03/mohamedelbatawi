#ifndef APP_TM_MEMORY_H
#define APP_TM_MEMORY_H

#include "def.h"

void app_tm_memory_process(uint32_t period);

#endif
