#include "def.h"

#include "app_test_mode.h"

void app_tm_memory_process(uint32_t period)
{
    // do nothing
}
