#ifndef APP_TM_DISPLAY_H
#define APP_TM_DISPLAY_H

#include "def.h"

void app_tm_display_process(uint32_t period);

#endif
