#ifndef APP_TM_COOLING_FAN_H
#define APP_TM_COOLING_FAN_H

#include "def.h"

void app_tm_coolingFan_process(uint32_t period);

#endif
