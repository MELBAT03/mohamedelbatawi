#ifndef APP_TM_MOTOR_H
#define APP_TM_MOTOR_H

#include "def.h"

void app_tm_motor_process(uint32_t period);

#endif
