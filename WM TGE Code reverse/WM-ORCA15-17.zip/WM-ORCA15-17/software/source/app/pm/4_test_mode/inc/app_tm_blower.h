#ifndef APP_TM_BLOWER_H
#define APP_TM_BLOWER_H

#include "def.h"

void app_tm_blower_process(uint32_t period);

#endif
