#ifndef APP_TM_CONDENSER_H
#define APP_TM_CONDENSER_H

#include "def.h"

void app_tm_condenser_process(uint32_t period);

#endif
