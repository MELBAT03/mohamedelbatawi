#ifndef APP_STANDBY_MEMORY_H
#define APP_STANDBY_MEMORY_H

#include "def.h"

void app_standby_memory_process(uint32_t period);

#endif
