#ifndef APP_STANDBY_BLOWER_H
#define APP_STANDBY_BLOWER_H

#include "def.h"

void app_standby_blower_process(uint32_t period);

#endif
