#ifndef APP_STANDBY_MOTOR_H
#define APP_STANDBY_MOTOR_H

#include "def.h"

void app_standby_motor_process(uint32_t period);

#endif
