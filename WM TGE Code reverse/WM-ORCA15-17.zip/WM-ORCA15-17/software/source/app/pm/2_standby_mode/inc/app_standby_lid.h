#ifndef APP_STANDBY_LID_H
#define APP_STANDBY_LID_H

#include "def.h"

void app_standby_lid_process(uint32_t period);

#endif
