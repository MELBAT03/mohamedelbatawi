#include "def.h"

#include "app_memory.h"

#include "app_standby_memory.h"

void app_standby_memory_process(uint32_t period)
{
    // do nothing
}
