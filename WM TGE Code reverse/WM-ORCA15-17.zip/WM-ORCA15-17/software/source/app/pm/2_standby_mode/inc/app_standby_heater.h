#ifndef APP_STANDBY_HEATER_H
#define APP_STANDBY_HEATER_H

#include "def.h"

void app_standby_heater_process(uint32_t period);

#endif
