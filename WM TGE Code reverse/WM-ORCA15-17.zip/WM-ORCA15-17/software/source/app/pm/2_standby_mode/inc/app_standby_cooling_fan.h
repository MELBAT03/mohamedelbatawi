#ifndef APP_STANDBY_COOLING_FAN_H
#define APP_STANDBY_COOLING_FAN_H

#include "def.h"

void app_standby_coolingFan_process(uint32_t period);

#endif
