#ifndef APP_STANDBY_DRAIN_H
#define APP_STANDBY_DRAIN_H

#include "def.h"

void app_standby_drain_process(uint32_t period);

#endif
