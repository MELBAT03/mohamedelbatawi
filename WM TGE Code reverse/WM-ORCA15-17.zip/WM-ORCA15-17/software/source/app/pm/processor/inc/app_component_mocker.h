#ifndef APP_COMPONENT_MOCKER_H
#define APP_COMPONENT_MOCKER_H

#include "def.h"

void app_cMocker_init(void);
void app_cMocker_update(uint32_t period);

#endif
