#ifndef APP_LOAD_H
#define APP_LOAD_H

#include "def.h"

uint32_t app_load_weightG_get(void);
uint32_t app_load_weightRaw_get(void);

#endif
