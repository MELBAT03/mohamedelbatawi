#ifndef APP_CONTROLLER_H
#define APP_CONTROLLER_H

#include "def.h"

void app_controller_update(uint32_t period);

#endif
