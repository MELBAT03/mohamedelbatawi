#ifndef APP_FINISH_DRAIN_H
#define APP_FINISH_DRAIN_H

#include "def.h"

void app_finish_drain_process(uint32_t period);

#endif
