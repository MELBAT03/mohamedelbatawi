#ifndef APP_FINISH_HEATER_H
#define APP_FINISH_HEATER_H

#include "def.h"

void app_finish_heater_process(uint32_t period);

#endif
