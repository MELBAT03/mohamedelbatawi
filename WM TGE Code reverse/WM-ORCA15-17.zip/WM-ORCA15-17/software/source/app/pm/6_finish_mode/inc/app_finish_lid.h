#ifndef APP_FINISH_LID_H
#define APP_FINISH_LID_H

#include "def.h"

void app_finish_lid_process(uint32_t period);

#endif
