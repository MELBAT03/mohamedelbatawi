#ifndef APP_FINISH_H
#define APP_FINISH_H

#include "def.h"
#include "app_processor.h"

app_processor_state_t app_finish_process(uint32_t period);

#endif
