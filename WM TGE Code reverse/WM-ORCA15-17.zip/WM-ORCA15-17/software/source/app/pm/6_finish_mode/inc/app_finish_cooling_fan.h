#ifndef APP_FINISH_COOLING_FAN_H
#define APP_FINISH_COOLING_FAN_H

#include "def.h"

void app_finish_coolingFan_process(uint32_t period);

#endif
