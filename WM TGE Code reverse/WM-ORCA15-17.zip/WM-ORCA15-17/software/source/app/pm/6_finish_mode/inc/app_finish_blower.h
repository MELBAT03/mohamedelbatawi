#ifndef APP_FINISH_BLOWER_H
#define APP_FINISH_BLOWER_H

#include "def.h"

void app_finish_blower_process(uint32_t period);

#endif
