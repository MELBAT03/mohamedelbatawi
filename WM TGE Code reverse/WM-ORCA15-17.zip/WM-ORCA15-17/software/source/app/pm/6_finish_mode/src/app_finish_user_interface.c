#include "def.h"

#include "app_finish_user_interface.h"

#include "app_memory.h"
#include "app_user_interface.h"
#include "app_nm_user_interface.h"

void app_finish_userInterface_process(uint32_t period)
{
    // do nothing
}
