#ifndef APP_FINISH_MEMORY_H
#define APP_FINISH_MEMORY_H

#include "def.h"

void app_finish_memory_process(uint32_t period);

#endif
