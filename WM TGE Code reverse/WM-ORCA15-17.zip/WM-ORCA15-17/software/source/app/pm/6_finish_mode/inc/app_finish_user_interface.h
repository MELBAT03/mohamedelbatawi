#ifndef APP_FINISH_USER_INTERFACE_H
#define APP_FINISH_USER_INTERFACE_H

#include "def.h"

void app_finish_userInterface_process(uint32_t period);

#endif
