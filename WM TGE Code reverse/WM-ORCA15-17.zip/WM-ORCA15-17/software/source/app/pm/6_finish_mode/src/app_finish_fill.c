#include "def.h"
#include "app_fill.h"
#include "app_finish_fill.h"

void app_finish_fill_process(uint32_t period)
{
    app_fill_stop();
}
