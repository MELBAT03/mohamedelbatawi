#ifndef APP_FINISH_MOTOR_H
#define APP_FINISH_MOTOR_H

#include "def.h"

void app_finish_motor_process(uint32_t period);

#endif
