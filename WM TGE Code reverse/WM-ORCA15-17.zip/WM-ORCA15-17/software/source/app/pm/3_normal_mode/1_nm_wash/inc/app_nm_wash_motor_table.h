#ifndef APP_NM_WASH_MOTOR_TABLE_H
#define APP_NM_WASH_MOTOR_TABLE_H

#include "app_nm_wash_soak_motor_table.h"
#include "app_nm_wash_wash_motor_table.h"
#include "app_nm_wash_steam_motor_table.h"
#include "app_nm_wash_rinse_motor_table.h"
#include "app_nm_wash_spin_motor_table.h"

#endif
