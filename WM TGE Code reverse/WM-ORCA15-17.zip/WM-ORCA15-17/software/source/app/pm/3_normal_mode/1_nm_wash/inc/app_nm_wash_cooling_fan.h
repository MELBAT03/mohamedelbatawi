#ifndef APP_NM_WASH_COOLING_FAN_H
#define APP_NM_WASH_COOLING_FAN_H

#include "def.h"

void app_nm_wash_coolingFan_process(uint32_t period);

#endif
