#ifndef APP_NM_TUBCLEAN_DRAIN_H
#define APP_NM_TUBCLEAN_DRAIN_H

#include "def.h"

void app_nm_tubclean_drain_process(uint32_t period);

#endif
