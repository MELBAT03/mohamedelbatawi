#ifndef APP_NORMAL_MODE_CONDENSER_H
#define APP_NORMAL_MODE_CONDENSER_H

#include "def.h"

void app_nm_condenser_process(uint32_t period);

#endif
