#ifndef APP_NM_FINISH_CONDENSER_H
#define APP_NM_FINISH_CONDENSER_H

#include "def.h"

void app_nm_finish_condenser_process(uint32_t period);

#endif
