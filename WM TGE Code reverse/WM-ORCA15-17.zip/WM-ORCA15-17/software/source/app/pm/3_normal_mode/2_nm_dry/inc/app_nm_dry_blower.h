#ifndef APP_NM_DRY_BLOWER_H
#define APP_NM_DRY_BLOWER_H

#include "def.h"

void app_nm_dry_blower_process(uint32_t period);

#endif
