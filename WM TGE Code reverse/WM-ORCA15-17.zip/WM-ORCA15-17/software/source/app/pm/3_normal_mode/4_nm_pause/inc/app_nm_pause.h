#ifndef APP_NM_PAUSE_H
#define APP_NM_PAUSE_H

#include "def.h"
#include "app_nm.h"

app_nm_state_t app_nm_pause_process(uint32_t period);

#endif
