#ifndef APP_NM_TUBCLEAN_LID_H
#define APP_NM_TUBCLEAN_LID_H

#include "def.h"

void app_nm_tubclean_lid_process(uint32_t period);

#endif
