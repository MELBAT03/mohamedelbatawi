#ifndef APP_NM_INIT_HEATER_H
#define APP_NM_INIT_HEATER_H

#include "def.h"

void app_nm_init_heater_process(uint32_t period);

#endif
