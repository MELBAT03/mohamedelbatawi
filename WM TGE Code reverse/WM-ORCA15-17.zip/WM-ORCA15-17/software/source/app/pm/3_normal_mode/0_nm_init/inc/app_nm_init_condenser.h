#ifndef APP_NM_INIT_CONDENSER_H
#define APP_NM_INIT_CONDENSER_H

#include "def.h"

void app_nm_init_condenser_process(uint32_t period);

#endif
