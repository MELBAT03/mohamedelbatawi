#ifndef APP_NM_PAUSE_USER_INTERFACE_H
#define APP_NM_PAUSE_USER_INTERFACE_H

#include "def.h"

void app_nm_pause_userInterface_process(uint32_t period);

#endif
