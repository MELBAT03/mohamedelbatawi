#ifndef APP_NORMAL_MODE_DRAIN_H
#define APP_NORMAL_MODE_DRAIN_H

#include "def.h"

void app_nm_drain_process(uint32_t period);

#endif
