#ifndef APP_NM_PAUSE_FILL_H
#define APP_NM_PAUSE_FILL_H

#include "def.h"

void app_nm_pause_fill_process(uint32_t period);

#endif
