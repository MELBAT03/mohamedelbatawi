#ifndef APP_NM_DRY_LID_H
#define APP_NM_DRY_LID_H

#include "def.h"

void app_nm_dry_lid_process(uint32_t period);

#endif
