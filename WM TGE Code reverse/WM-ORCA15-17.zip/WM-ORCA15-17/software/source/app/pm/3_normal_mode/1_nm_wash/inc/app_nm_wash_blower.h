#ifndef APP_NM_WASH_BLOWER_H
#define APP_NM_WASH_BLOWER_H

#include "def.h"

void app_nm_wash_blower_process(uint32_t period);

#endif
