#ifndef APP_NM_TUBCLEAN_HEATER_TABLE_H
#define APP_NM_TUBCLEAN_HEATER_TABLE_H

#include "def.h"

static const uint32_t tubclean_steamTechONTempTable = 70;
static const uint32_t tubclean_steamTechOFFTempTable = 65;

#endif
