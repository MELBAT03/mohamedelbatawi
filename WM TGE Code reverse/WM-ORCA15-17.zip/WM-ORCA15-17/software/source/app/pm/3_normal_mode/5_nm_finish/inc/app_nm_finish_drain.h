#ifndef APP_NM_FINISH_DRAIN_H
#define APP_NM_FINISH_DRAIN_H

#include "def.h"

void app_nm_finish_drain_process(uint32_t period);

#endif
