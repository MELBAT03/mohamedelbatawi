#ifndef APP_NM_TUBCLEAN_DISPLAY_H
#define APP_NM_TUBCLEAN_DISPLAY_H

#include "def.h"

void app_nm_tubclean_display_process(uint32_t period);

#endif
