#ifndef APP_NM_FINISH_DISPLAY_H
#define APP_NM_FINISH_DISPLAY_H

#include "def.h"

void app_nm_finish_display_process(uint32_t period);

#endif
