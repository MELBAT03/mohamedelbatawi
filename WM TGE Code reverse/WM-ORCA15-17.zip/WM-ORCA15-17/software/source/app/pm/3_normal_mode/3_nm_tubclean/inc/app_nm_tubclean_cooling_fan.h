#ifndef APP_NM_TUBCLEAN_COOLING_FAN_H
#define APP_NM_TUBCLEAN_COOLING_FAN_H

#include "def.h"

void app_nm_tubclean_coolingFan_process(uint32_t period);

#endif
