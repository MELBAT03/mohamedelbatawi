#ifndef APP_NM_DRY_DISPLAY_H
#define APP_NM_DRY_DISPLAY_H

#include "def.h"

void app_nm_dry_display_process(uint32_t period);

#endif
