#ifndef APP_NM_WASH_DEFAULTS_H
#define APP_NM_WASH_DEFAULTS_H

#include "def.h"
#include "app_nm_user_interface.h"
#include "app_nm_wash_user_interface.h"
#ifdef AUTO_DETERGENT_HEATER_MODEL
// NOTE: defaults
static const app_nm_wash_userInterface_defaults_data_t course_cotton_defaultsTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_WARM, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_12_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_2_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_5_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_NORMAL, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_ON, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_ON, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_ON},
    {0},
    {0},
    {0}};
// NOTE: LOWER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_cotton_defaulsLowLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_WARM, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_0_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_0_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_0_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_LIGHT, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_ON, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};
// NOTE: UPPER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_cotton_defaulsHighLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_HOT, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_LIMIT, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_4_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_18_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_3_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_EXTENDED, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_20_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_HEAVY, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_ON, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_ON, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_ON},
    {0},
    {0},
    {0}};

// defaults per level
static const app_nm_wash_userInterface_washTimeSelection_t course_cotton_defaultWashTimePerWaterLevelTable[] = {
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN};

static const uint8_t course_cotton_overloadingErrorEnable = 0;

// -------------------------------------------------------------------------------------------------------

// NOTE: defaults
static const app_nm_wash_userInterface_defaults_data_t course_white_defaultsTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_WARM, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_12_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_2_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_5_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_NORMAL, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_ON, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_ON, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_ON},
    {0},
    {0},
    {0}};
// NOTE: LOWER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_white_defaulsLowLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_WARM, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_0_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_0_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_0_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_LIGHT, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_ON, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};
// NOTE: UPPER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_white_defaulsHighLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_HOT, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_LIMIT, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_4_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_18_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_3_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_EXTENDED, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_20_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_HEAVY, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_ON, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_ON, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_ON},
    {0},
    {0},
    {0}};

// defaults per level
static const app_nm_wash_userInterface_washTimeSelection_t course_white_defaultWashTimePerWaterLevelTable[] = {
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN};

static const uint8_t course_white_overloadingErrorEnable = 0;

// -------------------------------------------------------------------------------------------------------

// NOTE: defaults
static const app_nm_wash_userInterface_defaults_data_t course_dark_defaultsTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_COLD, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_9_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_2_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_5_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_NORMAL, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_ON},
    {0},
    {0},
    {0}};
// NOTE: LOWER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_dark_defaulsLowLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_COLD, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_0_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_0_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_0_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_LIGHT, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_ON},
    {0},
    {0},
    {0}};
// NOTE: UPPER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_dark_defaulsHighLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_WARM, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_LIMIT, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_4_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_18_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_3_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_EXTENDED, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_20_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_HEAVY, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_ON},
    {0},
    {0},
    {0}};

// defaults per level
static const app_nm_wash_userInterface_washTimeSelection_t course_dark_defaultWashTimePerWaterLevelTable[] = {
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN};

static const uint8_t course_dark_overloadingErrorEnable = 0;

// -------------------------------------------------------------------------------------------------------

// NOTE: defaults
static const app_nm_wash_userInterface_defaults_data_t course_light_defaultsTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_COLD, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_9_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_2_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_5_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_NORMAL, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_ON},
    {0},
    {0},
    {0}};
// NOTE: LOWER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_light_defaulsLowLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_COLD, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_0_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_0_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_0_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_LIGHT, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};
// NOTE: UPPER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_light_defaulsHighLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_WARM, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_LIMIT, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_4_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_18_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_3_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_EXTENDED, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_20_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_HEAVY, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_ON},
    {0},
    {0},
    {0}};

// defaults per level
static const app_nm_wash_userInterface_washTimeSelection_t course_light_defaultWashTimePerWaterLevelTable[] = {
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN};

static const uint8_t course_light_overloadingErrorEnable = 0;

// -------------------------------------------------------------------------------------------------------

// NOTE: defaults
static const app_nm_wash_userInterface_defaults_data_t course_bedding_defaultsTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_COLD, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_LIMIT, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_12_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_2_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_9_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_NORMAL, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_ON},
    {0},
    {0},
    {0}};
// NOTE: LOWER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_bedding_defaulsLowLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_COLD, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_LIMIT, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_0_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_0_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_0_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_LIGHT, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};
// NOTE: UPPER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_bedding_defaulsHighLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_HOT, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_LIMIT, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_18_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_3_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_EXTENDED, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_20_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_HEAVY, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_ON},
    {0},
    {0},
    {0}};

// defaults per level
static const app_nm_wash_userInterface_washTimeSelection_t course_bedding_defaultWashTimePerWaterLevelTable[] = {
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN};

static const uint8_t course_bedding_overloadingErrorEnable = 0;

// -------------------------------------------------------------------------------------------------------

// NOTE: defaults
static const app_nm_wash_userInterface_defaults_data_t course_babycare_defaultsTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_COLD, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_12_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_2_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_5_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_NORMAL, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_ON},
    {0},
    {0},
    {0}};
// NOTE: LOWER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_babycare_defaulsLowLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_COLD, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_0_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_0_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_0_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_LIGHT, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};
// NOTE: UPPER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_babycare_defaulsHighLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_HOT, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_LIMIT, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_4_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_18_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_3_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_EXTENDED, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_20_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_HEAVY, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_ON},
    {0},
    {0},
    {0}};

// defaults per level
static const app_nm_wash_userInterface_washTimeSelection_t course_babycare_defaultWashTimePerWaterLevelTable[] = {
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN};

static const uint8_t course_babycare_overloadingErrorEnable = 0;

// -------------------------------------------------------------------------------------------------------

// NOTE: defaults
static const app_nm_wash_userInterface_defaults_data_t course_eco_defaultsTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_COLD, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_12_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_1_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_5_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_NORMAL, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_ON, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_ON},
    {0},
    {0},
    {0}};
// NOTE: LOWER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_eco_defaulsLowLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_COLD, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_0_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_0_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_0_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_LIGHT, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_ON, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};
// NOTE: UPPER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_eco_defaulsHighLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_COLD, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_LIMIT, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_4_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_18_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_3_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_EXTENDED, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_20_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_HEAVY, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_ON, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_ON},
    {0},
    {0},
    {0}};

// defaults per level
static const app_nm_wash_userInterface_washTimeSelection_t course_eco_defaultWashTimePerWaterLevelTable[] = {
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN};

static const uint8_t course_eco_overloadingErrorEnable = 0;

// -------------------------------------------------------------------------------------------------------

// NOTE: defaults
static const app_nm_wash_userInterface_defaults_data_t course_jeans_defaultsTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_WARM, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_12_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_2_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_9_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_NORMAL, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_ON},
    {0},
    {0},
    {0}};
// NOTE: LOWER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_jeans_defaulsLowLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_COLD, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_0_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_0_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_0_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_LIGHT, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};
// NOTE: UPPER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_jeans_defaulsHighLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_HOT, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_LIMIT, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_4_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_18_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_3_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_EXTENDED, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_20_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_HEAVY, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_ON},
    {0},
    {0},
    {0}};

// defaults per level
static const app_nm_wash_userInterface_washTimeSelection_t course_jeans_defaultWashTimePerWaterLevelTable[] = {
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN};

static const uint8_t course_jeans_overloadingErrorEnable = 0;

// -------------------------------------------------------------------------------------------------------

// NOTE: defaults
static const app_nm_wash_userInterface_defaults_data_t course_mix_defaultsTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_WARM, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_12_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_2_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_5_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_NORMAL, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_ON},
    {0},
    {0},
    {0}};
// NOTE: LOWER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_mix_defaulsLowLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_COLD, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_0_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_0_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_0_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_LIGHT, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};
// NOTE: UPPER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_mix_defaulsHighLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_HOT, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_LIMIT, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_4_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_18_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_3_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_EXTENDED, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_20_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_HEAVY, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_ON},
    {0},
    {0},
    {0}};

// defaults per level
static const app_nm_wash_userInterface_washTimeSelection_t course_mix_defaultWashTimePerWaterLevelTable[] = {
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN};

static const uint8_t course_mix_overloadingErrorEnable = 0;

// -------------------------------------------------------------------------------------------------------

// NOTE: defaults
static const app_nm_wash_userInterface_defaults_data_t course_delicate_defaultsTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_COLD, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_5, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_9_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_2_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_5_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_NORMAL, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_ON},
    {0},
    {0},
    {0}};
// NOTE: LOWER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_delicate_defaulsLowLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_COLD, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_0_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_0_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_0_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_LIGHT, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};
// NOTE: UPPER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_delicate_defaulsHighLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_COLD, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_LIMIT, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_18_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_3_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_EXTENDED, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_20_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_HEAVY, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_ON},
    {0},
    {0},
    {0}};

// defaults per level
static const app_nm_wash_userInterface_washTimeSelection_t course_delicate_defaultWashTimePerWaterLevelTable[] = {
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN};

static const uint8_t course_delicate_overloadingErrorEnable = 0;

// -------------------------------------------------------------------------------------------------------

// NOTE: defaults
static const app_nm_wash_userInterface_defaults_data_t course_sports_defaultsTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_WARM, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_12_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_2_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_5_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_NORMAL, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_ON},
    {0},
    {0},
    {0}};
// NOTE: LOWER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_sports_defaulsLowLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_COLD, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_0_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_0_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_0_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_LIGHT, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};
// NOTE: UPPER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_sports_defaulsHighLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_HOT, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_LIMIT, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_4_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_18_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_3_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_EXTENDED, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_20_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_HEAVY, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_ON},
    {0},
    {0},
    {0}};

// defaults per level
static const app_nm_wash_userInterface_washTimeSelection_t course_sports_defaultWashTimePerWaterLevelTable[] = {
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN};

static const uint8_t course_sports_overloadingErrorEnable = 0;

// -------------------------------------------------------------------------------------------------------

// NOTE: defaults
static const app_nm_wash_userInterface_defaults_data_t course_alergy_defaultsTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_WARM, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_12_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_3_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_5_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_NORMAL, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_ON, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_ON, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_ON},
    {0},
    {0},
    {0}};
// NOTE: LOWER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_alergy_defaulsLowLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_WARM, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_0_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_0_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_0_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_LIGHT, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_ON, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};
// NOTE: UPPER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_alergy_defaulsHighLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_HOT, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_5, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_4_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_18_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_3_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_EXTENDED, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_20_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_HEAVY, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_ON, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_ON, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_ON},
    {0},
    {0},
    {0}};

// defaults per level
static const app_nm_wash_userInterface_washTimeSelection_t course_alergy_defaultWashTimePerWaterLevelTable[] = {
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN};

static const uint8_t course_alergy_overloadingErrorEnable = 1;

#else
// NOTE: defaults
static const app_nm_wash_userInterface_defaults_data_t course_cotton_defaultsTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_WARM, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_12_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_2_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_5_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_NORMAL, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};
// NOTE: LOWER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_cotton_defaulsLowLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_COLD, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_0_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_0_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_0_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_LIGHT, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};
// NOTE: UPPER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_cotton_defaulsHighLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_HOT, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_LIMIT, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_4_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_18_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_3_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_EXTENDED, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_9_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_HEAVY, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_20_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};

// defaults per level
static const app_nm_wash_userInterface_washTimeSelection_t course_cotton_defaultWashTimePerWaterLevelTable[] = {
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN};

static const uint8_t course_cotton_overloadingErrorEnable = 0;

// -------------------------------------------------------------------------------------------------------

// NOTE: defaults
static const app_nm_wash_userInterface_defaults_data_t course_white_defaultsTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_WARM, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_12_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_2_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_5_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_NORMAL, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};
// NOTE: LOWER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_white_defaulsLowLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_COLD, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_0_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_0_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_0_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_LIGHT, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};
// NOTE: UPPER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_white_defaulsHighLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_HOT, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_LIMIT, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_4_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_18_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_3_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_EXTENDED, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_9_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_HEAVY, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_20_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};

// defaults per level
static const app_nm_wash_userInterface_washTimeSelection_t course_white_defaultWashTimePerWaterLevelTable[] = {
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN};

static const uint8_t course_white_overloadingErrorEnable = 0;

// -------------------------------------------------------------------------------------------------------

// NOTE: defaults
static const app_nm_wash_userInterface_defaults_data_t course_dark_defaultsTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_COLD, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_9_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_2_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_5_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_NORMAL, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};
// NOTE: LOWER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_dark_defaulsLowLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_COLD, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_0_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_0_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_0_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_LIGHT, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};
// NOTE: UPPER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_dark_defaulsHighLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_WARM, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_LIMIT, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_4_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_18_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_3_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_EXTENDED, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_9_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_HEAVY, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_20_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};

// defaults per level
static const app_nm_wash_userInterface_washTimeSelection_t course_dark_defaultWashTimePerWaterLevelTable[] = {
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN};

static const uint8_t course_dark_overloadingErrorEnable = 0;

// -------------------------------------------------------------------------------------------------------

// NOTE: defaults
static const app_nm_wash_userInterface_defaults_data_t course_light_defaultsTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_COLD, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_9_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_2_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_5_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_NORMAL, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};
// NOTE: LOWER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_light_defaulsLowLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_COLD, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_0_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_0_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_0_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_LIGHT, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};
// NOTE: UPPER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_light_defaulsHighLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_WARM, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_LIMIT, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_4_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_18_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_3_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_EXTENDED, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_9_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_HEAVY, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_20_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};

// defaults per level
static const app_nm_wash_userInterface_washTimeSelection_t course_light_defaultWashTimePerWaterLevelTable[] = {
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN};

static const uint8_t course_light_overloadingErrorEnable = 0;

// -------------------------------------------------------------------------------------------------------

// NOTE: defaults
static const app_nm_wash_userInterface_defaults_data_t course_bedding_defaultsTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_COLD, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_LIMIT, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_12_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_2_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_9_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_NORMAL, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};
// NOTE: LOWER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_bedding_defaulsLowLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_COLD, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_LIMIT, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_0_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_0_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_0_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_LIGHT, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};
// NOTE: UPPER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_bedding_defaulsHighLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_HOT, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_LIMIT, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_18_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_3_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_EXTENDED, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_9_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_HEAVY, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_20_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};

// defaults per level
static const app_nm_wash_userInterface_washTimeSelection_t course_bedding_defaultWashTimePerWaterLevelTable[] = {
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN};

static const uint8_t course_bedding_overloadingErrorEnable = 0;

// -------------------------------------------------------------------------------------------------------

// NOTE: defaults
static const app_nm_wash_userInterface_defaults_data_t course_babycare_defaultsTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_COLD, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_12_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_2_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_5_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_NORMAL, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};
// NOTE: LOWER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_babycare_defaulsLowLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_COLD, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_0_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_0_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_0_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_LIGHT, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};
// NOTE: UPPER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_babycare_defaulsHighLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_HOT, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_LIMIT, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_4_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_18_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_3_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_EXTENDED, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_9_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_HEAVY, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_20_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};

// defaults per level
static const app_nm_wash_userInterface_washTimeSelection_t course_babycare_defaultWashTimePerWaterLevelTable[] = {
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN};

static const uint8_t course_babycare_overloadingErrorEnable = 0;

// -------------------------------------------------------------------------------------------------------

// NOTE: defaults
static const app_nm_wash_userInterface_defaults_data_t course_wool_defaultsTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_COLD, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_5, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_3_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_1_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_1_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_NONE, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};
// NOTE: LOWER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_wool_defaulsLowLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_COLD, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_5, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_0_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_0_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_0_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_NONE, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};
// NOTE: UPPER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_wool_defaulsHighLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_COLD, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_LIMIT, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_3_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_1_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_1_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_NONE, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};

// defaults per level
static const app_nm_wash_userInterface_washTimeSelection_t course_wool_defaultWashTimePerWaterLevelTable[] = {
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN};

static const uint8_t course_wool_overloadingErrorEnable = 0;

// -------------------------------------------------------------------------------------------------------

// NOTE: defaults
static const app_nm_wash_userInterface_defaults_data_t course_jeans_defaultsTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_WARM, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_12_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_2_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_9_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_NORMAL, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};
// NOTE: LOWER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_jeans_defaulsLowLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_COLD, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_0_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_0_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_0_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_LIGHT, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};
// NOTE: UPPER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_jeans_defaulsHighLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_HOT, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_LIMIT, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_4_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_18_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_3_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_EXTENDED, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_9_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_HEAVY, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_20_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};

// defaults per level
static const app_nm_wash_userInterface_washTimeSelection_t course_jeans_defaultWashTimePerWaterLevelTable[] = {
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN};

static const uint8_t course_jeans_overloadingErrorEnable = 0;

// -------------------------------------------------------------------------------------------------------

// NOTE: defaults
static const app_nm_wash_userInterface_defaults_data_t course_mix_defaultsTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_WARM, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_12_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_2_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_5_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_NORMAL, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};
// NOTE: LOWER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_mix_defaulsLowLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_COLD, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_0_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_0_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_0_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_LIGHT, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};
// NOTE: UPPER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_mix_defaulsHighLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_HOT, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_LIMIT, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_4_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_18_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_3_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_EXTENDED, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_9_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_HEAVY, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_20_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};

// defaults per level
static const app_nm_wash_userInterface_washTimeSelection_t course_mix_defaultWashTimePerWaterLevelTable[] = {
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN};

static const uint8_t course_mix_overloadingErrorEnable = 0;

// -------------------------------------------------------------------------------------------------------

// NOTE: defaults
static const app_nm_wash_userInterface_defaults_data_t course_delicate_defaultsTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_COLD, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_5, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_9_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_2_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_5_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_NORMAL, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};
// NOTE: LOWER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_delicate_defaulsLowLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_COLD, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_0_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_0_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_0_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_LIGHT, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};
// NOTE: UPPER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_delicate_defaulsHighLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_COLD, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_LIMIT, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_18_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_3_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_EXTENDED, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_9_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_HEAVY, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};

// defaults per level
static const app_nm_wash_userInterface_washTimeSelection_t course_delicate_defaultWashTimePerWaterLevelTable[] = {
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_9_MIN};

static const uint8_t course_delicate_overloadingErrorEnable = 0;

// -------------------------------------------------------------------------------------------------------

// NOTE: defaults
static const app_nm_wash_userInterface_defaults_data_t course_sports_defaultsTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_WARM, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_12_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_2_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_5_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_NORMAL, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};
// NOTE: LOWER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_sports_defaulsLowLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_COLD, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_0_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_0_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_0_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_LIGHT, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};
// NOTE: UPPER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_sports_defaulsHighLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_HOT, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_LIMIT, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_4_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_18_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_3_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_EXTENDED, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_9_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_HEAVY, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};

// defaults per level
static const app_nm_wash_userInterface_washTimeSelection_t course_sports_defaultWashTimePerWaterLevelTable[] = {
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_12_MIN};

static const uint8_t course_sports_overloadingErrorEnable = 0;

// -------------------------------------------------------------------------------------------------------

// NOTE: defaults
static const app_nm_wash_userInterface_defaults_data_t course_rapidWash_defaultsTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_WARM, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_3_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_1_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_5_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_NORMAL, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};
// NOTE: LOWER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_rapidWash_defaulsLowLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_COLD, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_0, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_0_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_0_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_OVERFLOW_OFF_SHOWER_OFF, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_0_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_LIGHT, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};
// NOTE: UPPER LIMIT FOR SELECTION
static const app_nm_wash_userInterface_defaults_data_t course_rapidWash_defaulsHighLimitTable[APP_NORMAL_MODE_UI_OPERATION_WASH_DRY_OPTOIN_NUM] = {
    {0},
    {.defaultWaterTemp = APP_NORMAL_MODE_UI_WATER_TEMP_HOT, .defaultWaterLevel = APP_NORMAL_MODE_WASH_UI_WATER_LEVEL_10, .defaultSoakTime = APP_NORMAL_MODE_UI_SOAK_TIME_0_HOUR, .defaultWashTime = APP_NORMAL_MODE_UI_WASH_TIME_18_MIN, .defaultSteam = APP_NORMAL_MODE_UI_STEAM_OFF, .defaultRinseTime = APP_NORMAL_MODE_UI_RINSE_3_TIMES, .defaultExtraRinse = APP_NORMAL_MODE_UI_RINSE_EXTENDED, .defaultSpinTime = APP_NORMAL_MODE_UI_SPIN_TIME_9_MIN, .defaultSoilLevel = APP_NORMAL_MODE_UI_SOIL_LEVEL_HEAVY, .defaultSuperSpinTime = APP_NORMAL_MODE_UI_SUPER_SPIN_TIME_0_MIN, .defaultAntiWrinkle = APP_NORMAL_MODE_UI_ANTI_WRINKLE_TIME_0_MIN, .defaultSteamTech = APP_NORMAL_MODE_UI_STEAM_TECH_OFF, .defaultWaterHeating = APP_NORMAL_MODE_UI_WATER_HEATING_OFF, .defaultGelDetergent = APP_NORMAL_MODE_UI_GEL_DETERGENT_OFF},
    {0},
    {0},
    {0}};

// defaults per level
static const app_nm_wash_userInterface_washTimeSelection_t course_rapidWash_defaultWashTimePerWaterLevelTable[] = {
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN,
    APP_NORMAL_MODE_UI_WASH_TIME_3_MIN};

static const uint8_t course_rapidWash_overloadingErrorEnable = 0;

#endif

#endif
