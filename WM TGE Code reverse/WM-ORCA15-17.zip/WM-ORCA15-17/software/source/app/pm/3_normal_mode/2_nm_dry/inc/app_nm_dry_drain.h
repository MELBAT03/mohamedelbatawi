#ifndef APP_NM_DRY_DRAIN_H
#define APP_NM_DRY_DRAIN_H

#include "def.h"
#include "app_user_interface.h"

void app_nm_dry_drain_process(uint32_t period);

#endif
