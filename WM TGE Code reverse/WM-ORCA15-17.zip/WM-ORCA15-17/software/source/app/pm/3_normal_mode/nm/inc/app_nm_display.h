#ifndef APP_NM_DISPLAY_H
#define APP_NM_DISPLAY_H

#include "def.h"

void app_nm_display_process(uint32_t period);

#endif
