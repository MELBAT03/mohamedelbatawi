#ifndef APP_NM_FINISH_H
#define APP_NM_FINISH_H

#include "def.h"
#include "app_nm.h"

app_nm_state_t app_nm_finish_process(uint32_t period);

#endif
