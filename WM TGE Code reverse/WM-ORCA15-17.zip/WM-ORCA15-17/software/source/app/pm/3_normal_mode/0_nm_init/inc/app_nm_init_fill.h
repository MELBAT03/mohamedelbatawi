#ifndef APP_NM_INIT_FILL_H
#define APP_NM_INIT_FILL_H

#include "def.h"

void app_nm_init_fill_process(uint32_t period);

#endif
