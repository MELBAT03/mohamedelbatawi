#ifndef APP_INTERRUPT_H
#define APP_INTERRUPT_H

void app_interrupt_init(void);

#endif
