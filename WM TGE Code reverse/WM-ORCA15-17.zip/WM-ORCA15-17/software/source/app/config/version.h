#ifndef VERSION_H
#define VERSION_H

#define WM_SW_VERSION_MAJOR (0U)
#define WM_SW_VERSION_MINOR (6U)

#endif
